package com.example.breweryfix;

import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

public class BreweryFix extends JavaPlugin implements Listener {
    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("BreweryFix enabled.");
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        // Только ПКМ по блоку
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        // Только если кликают основной рукой
        if (event.getHand() != EquipmentSlot.HAND) return;

        Block clicked = event.getClickedBlock();
        if (clicked == null || clicked.getType() != Material.CAULDRON) return;

        Player player = event.getPlayer();
        ItemStack offHandItem = player.getInventory().getItemInOffHand();

        // Проверка: предмет в левой руке есть, стакаемый
        if (offHandItem != null && offHandItem.getType() != Material.AIR && offHandItem.getMaxStackSize() > 1) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "Уберите стакаемый предмет из второй руки.");
        }
    }
}
